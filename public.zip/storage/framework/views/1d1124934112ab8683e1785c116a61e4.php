<?php $__env->startSection('content'); ?>
<div class="container-xxl flex-grow-1 container-p-y px-4">
    <div class="row g-6">

        <!-- Form controls -->
        <div class="col-md-12">
            <div class="card">
                <h5 class="card-header text-bold mt-3 mb-3">Edit Lessons</h5>
                <div class="card-body">
                    <form action="<?php echo e(route('master_lessons.update', $lessons->id)); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('PUT'); ?>

                        <div class="mb-4">
                            <label for="module_id" class="form-label">Pilih Module</label>
                            <select name="module_id" class="form-control" id="module_id">
                                <?php $__currentLoopData = $modules; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $module): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($module->id); ?>"
                                    <?php echo e($lessons->module_id == $module->id ? 'selected' : ''); ?>>
                                    <?php echo e($module->title); ?>

                                </option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>

                        <div class="mb-4">
                            <label for="title" class="form-label">Judul</label>
                            <input type="text" name="title" class="form-control" id="title"
                                placeholder="Masukkan Judul Lesson" value="<?php echo e($lessons->title); ?>" />
                        </div>
                        <div class="mb-4">
                            <label for="order" class="form-label">Urutan</label>
                            <input type="text" name="order" class="form-control" id="order"
                                placeholder="Masukkan Urutan Lesson" value="<?php echo e($lessons->order); ?>" min="1" />
                        </div>
                        <div class="mb-4">
                            <label for="description" class="form-label">Deskripsi</label>
                            <input type="text" name="description" class="form-control" id="description"
                                placeholder="Masukkan Deskripsi Anda" value="<?php echo e($lessons->description); ?>" />
                        </div>


                        <div class="row px-3">
                            <button class="btn btn-primary px-3">Simpan Perubahan</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>

    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH E:\Project\Spectra_Teacch\resources\views/master_lessons/edit.blade.php ENDPATH**/ ?>