<?php $__env->startSection('content'); ?>
<div class="container-xxl flex-grow-1 container-p-y px-4">
    <div class="row g-6">

        <!-- Form controls -->
        <div class="col-md-12">
            <div class="card">
                <h5 class="card-header text-bold mt-3 mb-3">Edit Lessons</h5>
                <div class="card-body">
                    <form action="<?php echo e(route('master_lessons.update', $lessons->id)); ?>" method="POST"
                        enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('PUT'); ?>

                        <div class="mb-4">
                            <label for="module_id" class="form-label">Pilih Module</label>

                            <input type="text" name="module_id" class="form-control" id="module_id"
                                placeholder="Masukkan Judul Lesson" value="<?php echo e($lessons->modules->title); ?>" readonly />
                        </div>

                        <div class="mb-4">
                            <label for="title" class="form-label">Judul</label>
                            <input type="text" name="title" class="form-control" id="title"
                                placeholder="Masukkan Judul Lesson" value="<?php echo e($lessons->title); ?>" readonly />
                        </div>
                        <div class="mb-3">
                            <label for="order" class="form-label">Urutan</label>
                            <input type="number" name="order" value="<?php echo e($lessons->order); ?>" id="order"
                                placeholder="Masukkan Urutan Lesson" class="form-control" readonly>
                        </div>
                        <div class="mb-4">
                            <label for="description" class="form-label">Deskripsi</label>
                            <input type="text" name="description" class="form-control" id="description"
                                placeholder="Masukkan Deskripsi Anda" value="<?php echo e($lessons->description); ?>" readonly />
                        </div>

                        <div class="mb-4">
                            <label for="file" class="form-label">File PDF</label>
                            <?php if($lessons->pdf_path): ?>
                            <p><a href="<?php echo e(asset('storage/' . $lessons->pdf_path)); ?>" target="_blank"
                                    class="btn btn-outline-primary">
                                    Lihat PDF
                                </a></p>
                            <?php else: ?>
                            <p><em>Tidak ada file PDF</em></p>
                            <?php endif; ?>
                        </div>

                        <!-- <div class="row px-3">
                            <button class="btn btn-primary px-3">Simpan Perubahan</button>
                        </div> -->
                    </form>
                </div>
            </div>
        </div>

    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH E:\Project\Spectra_Teacch\resources\views/master_lessons/detail.blade.php ENDPATH**/ ?>